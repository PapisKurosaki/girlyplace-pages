---
name: Modern Sahelian Luxury
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#594048'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#8d6f79'
  outline-variant: '#e1bdc8'
  surface-tint: '#b8006c'
  primary: '#b30069'
  on-primary: '#ffffff'
  primary-container: '#df0e84'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb0cc'
  secondary: '#7b5804'
  on-secondary: '#ffffff'
  secondary-container: '#fdcd74'
  on-secondary-container: '#785601'
  tertiary: '#831ada'
  on-tertiary: '#ffffff'
  tertiary-container: '#9e41f5'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e4'
  primary-fixed-dim: '#ffb0cc'
  on-primary-fixed: '#3e0021'
  on-primary-fixed-variant: '#8d0051'
  secondary-fixed: '#ffdea6'
  secondary-fixed-dim: '#eec068'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5d4200'
  tertiary-fixed: '#f0dbff'
  tertiary-fixed-dim: '#ddb8ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6800b4'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system embodies the "Girl Boss" energy of Senegal—a fusion of ultra-premium luxury, maternal warmth, and entrepreneurial grit. The brand personality is unapologetically feminine, sophisticated, and aspirational. It targets female entrepreneurs who value aesthetics as much as utility, positioning their products within a high-end digital boutique.

The design style merges **High-Contrast Minimalist** layouts with **Glassmorphism** overlays. It draws inspiration from high-fashion editorial spreads, utilizing expansive white space, sharp vertical rhythms, and soft, translucent layers to create a sense of depth and prestige. The emotional response should be one of empowerment, trust, and "Le Chic Sénégalais."

## Colors

The palette centers on **Fuchsia Pink**, used strategically for interactive elements and brand recognition. **Warm Gold** is reserved exclusively for "Premium" or "Verified" status indicators, high-value badges, and luxury UI accents to maintain its perceived value.

**Gradients:**
- `hero-gradient`: Linear 135deg from #E91E8C to #9333EA. Used for primary CTAs and high-impact hero banners.

**Surface Application:**
- **Primary Surface:** Pure White (#FFFFFF) to allow product photography to shine.
- **Section Alternation:** Light Rosy Gray (#FDF2F8) used to differentiate vendor blocks or secondary content modules.
- **Overlays:** Semi-transparent white (rgba(255, 255, 255, 0.7)) with a 12px backdrop-blur for glassmorphic cards and navigation bars.

## Typography

The typographic hierarchy uses **Playfair Display** for all headings to signal elegance and authority. Note: "Be Vietnam Pro" is substituted for "Poppins" to provide a more contemporary, refined, and professional "Girl Boss" aesthetic while maintaining the requested friendly rounded character.

- **Headlines:** Use Playfair Display with tighter letter-spacing for large display sizes.
- **Body:** Use Be Vietnam Pro for optimal readability in product descriptions and vendor bios.
- **Labels:** Small labels and utility text should use Be Vietnam Pro in Semi-Bold with slight tracking (letter-spacing) to maintain a premium feel.
- **Language:** All placeholder text and UI labels must be in French (e.g., "Acheter maintenant," "Boutiques vedettes").

## Layout & Spacing

The design system utilizes a **12-column fluid grid** for desktop with a maximum container width of 1280px. 

- **Grid Logic:** 24px gutters provide ample breathing room between product tiles, mimicking an Instagram-style visual feed.
- **Margins:** Generous 64px side margins on desktop focus the user's eye on the center-weighted content.
- **Vertical Rhythm:** Use a 4px baseline grid. Spacing between related elements (label to input) is 8px; spacing between sections is 80px to 120px to maintain the luxury feel.
- **Mobile Adaptation:** Columns collapse to a 2-column grid for product feeds to maximize image visibility, with 20px side margins.

## Elevation & Depth

Hierarchy is established through **Soft Ambient Shadows** and **Glassmorphism**.

- **Level 1 (Cards):** A soft Fuchsia-tinted shadow `0 4px 20px rgba(233, 30, 140, 0.08)`. This creates a subtle lift without appearing heavy.
- **Level 2 (Dropdowns/Modals):** A more pronounced shadow `0 12px 40px rgba(26, 26, 26, 0.12)` combined with a white semi-transparent background (Blur: 16px).
- **Interactive Depth:** On hover, cards and buttons should use a `translateY(-4px)` transition (200ms ease-out) to provide tactile feedback.
- **Glassmorphism:** Use for floating navigation bars and over-image labels (e.g., price tags on product photos).

## Shapes

The shape language is soft and sophisticated, avoiding aggressive sharp corners.

- **Cards & Containers:** 16px (`rounded-lg`) for all product tiles, vendor profile cards, and modal containers.
- **Buttons & Inputs:** 12px for standard UI controls.
- **Avatars:** 50% (Circle) for vendor and customer profile pictures, often paired with a 2px Gold or Fuchsia border to indicate "Live" status or "Premium" tier.
- **Icons:** Use rounded-style iconography to match the curvature of the typography.

## Components

### Buttons
- **Primary:** Fuchsia Pink background, white text, 12px radius. On hover, apply the `hero-gradient`.
- **Secondary/Luxury:** Ghost style with a 2px Warm Gold border and Gold text.
- **Tertiary:** Pure text in Fuchsia with a small heart icon suffix.

### Product Cards
- Aspect ratio 4:5 (Portrait) for high-fashion photography.
- Minimalist footer: Product name in Soft Black, Price in Fuchsia (Semi-bold).
- Heart icon in top-right corner; on click, trigger a scale(1.3) "pulse" animation.

### Chips & Badges
- **Premium Vendor:** Warm Gold background with #1A1A1A text and a star icon.
- **New Arrival:** Fuchsia background with white text.

### Input Fields
- Background: #FDF2F8 (Light Rosy Gray) or Pure White with a 1px #E5E7EB border.
- Focus State: 1px #E91E8C border with a 4px soft glow.

### Interactive Elements
- **Heart Pulse:** Wishlist icons should use a CSS keyframe pulse when toggled.
- **Vendor Feed:** A horizontal scrolling "Stories" bar at the top of the marketplace, featuring circular vendor avatars with Fuchsia/Gold rings.